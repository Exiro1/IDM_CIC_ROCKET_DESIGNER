function [] = Courbes_trajecto(nom_dossier,Portee,x,y,z,accelerations,accelerations_ang,vitesses,vitesses_ang,t)

mkdir(nom_dossier,'Trajectographie');

        %Trajectoire 3D
        figure()
        plot3(x,y,z)
        xlabel("X en m�tres")
        ylabel("Y en m�tres")
        zlabel("Altitude en m�tres")
        title("Trajectoire de la fus�e")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Trajectoire 3D'));

        %Courbe de l'altitude
        figure()
        plot(t,z)
        xlabel("Temps en secondes")
        ylabel("Altitude en m�tres")
        title("Evolution de l'altitude en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Altitude (z) vs Temps'));

        %Courbes de la port�e
        figure()
        plot(Portee,z)
        xlabel("Port�e en m�tres")
        ylabel("Altitude en m�tres")
        title("Evolution de l'altitude en fonction de la port�e")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Altitude vs Port�e'));
        
        %Courbes des acc�l�rations 
        figure()
        plot(t,accelerations)
        xlabel("Temps en secondes")
        ylabel("Acc�l�ration en m.s-2")
        title("Evolution des acc�l�rations en fonction du temps")
        legend('Ax','Ay','Az')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Acc�l�rations vs Temps'));
        
        figure()
        plot(t,accelerations_ang)
        xlabel("Temps en secondes")
        ylabel("Acc�l�ration angulaire en rad.s-2")
        title("Evolution des acc�l�rations angulaires en fonction du temps")
        legend('Aphi','Ath�ta','Apsi')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Acc�l�rations ang vs Temps'));

        figure()
        plot(z,accelerations)
        xlabel("Altitude en m�tres")
        ylabel("Acc�l�ration en m.s-2")
        title("Evolution des acc�l�rations en fonction de l'altitude")
        legend('Ax','Ay','Az')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Acc�l�rations vs Altitude'));

        %Courbes des vitesses
        figure()
        plot(t,vitesses)
        xlabel("Temps en secondes")
        ylabel("Vitesse en m.s-1")
        title("Evolution des vitesses en fonction du temps")
        legend('Vx','Vy','Vz')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Vitesses vs Temps'));

        figure()
        plot(t,vitesses_ang)
        xlabel("Temps en secondes")
        ylabel("Vitesse angulaire en rad.s-1")
        title("Evolution des vitesses angulaires en fonction du temps")
        legend('Vphi','Vth�ta','Vpsi')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Vitesses ang vs Temps'));
        
        figure()
        plot(z,vitesses)
        xlabel("Altitude en m�tres")
        ylabel("Vitesses en m.s-1")
        title("Evolution des vitesses en fonction de l'altitude")
        legend('Vx','Vy','Vz')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Vitesses vs Altitude'));

end