function [] = Courbes_Efforts_3DDL(nom_dossier,t,N,T,M_flexion,Nbr_section,xCDG0,Pdyn)

%Fonction qui :
%Cr�e une matrice d'effort en fonction du temps pour chaque section,
%Trace la courbe d'effort en fonction du temps pour chaque section,
%D�termine les valeurs maximales d'efforts pour chaque section.

pas_lim = size(t);
Effort_N = zeros(pas_lim(1,1),1);
Effort_T = zeros(pas_lim(1,1),1);
Moment = zeros(pas_lim(1,1),1);
Max_N=zeros(Nbr_section,2);
Max_T=zeros(Nbr_section,2);
Max_M=zeros(Nbr_section,2);
mkdir(nom_dossier,'Efforts');
[Pdyn_max,I_Pdyn_max] = max(abs(Pdyn));
I_Pdyn_max=I_Pdyn_max-1;
t_Pdyn_max=t(I_Pdyn_max);
    
    %Effort normal
    mkdir([nom_dossier,'\Efforts'],'Effort normal');
        for j=1:1:Nbr_section
    
            Effort_N(1,j)=N(j,1);
         for i=0:1:pas_lim(1,1)-1
                Effort_N(i+1,j) = N(j+i*Nbr_section,1);
         end
            [M,I] = max(abs(Effort_N(:,j)));
            Max_N(j,1)=M;
            Max_N(j,2)=t(I);
    
            figure()
            plot(t,Effort_N(:,j))
            xlabel("Temps (s)")
            ylabel("Effort (N)")
            title(['Effort normal exerc� sur la section ',num2str(j)])
            saveas(gcf,fullfile([nom_dossier,'\Efforts\Effort normal'],['Effort normal section ',num2str(j)]));
        end

        %Courbe de l'effort normal en fonction de l'abscisse x
        Eff_N_x=Effort_N(I_Pdyn_max,1:Nbr_section);
        figure()
        plot(xCDG0*0.001,Eff_N_x)
        xlabel("Abscisse(m)")
        ylabel("Effort Normal(N)")
        title('Effort Normal � pression dynamique max')
        saveas(gcf,fullfile([nom_dossier,'\Efforts\Effort normal'],'Effort normal fus�e'));
        
    %Effort tangentiel
    mkdir([nom_dossier,'\Efforts'],'Effort tangentiel');
        for j=1:1:Nbr_section
    
            Effort_T(1,j)=T(j,1);
            for i=0:1:pas_lim(1,1)-1
                Effort_T(i+1,j) = T(j+i*Nbr_section,1);
            end
            [M,I] = max(abs(Effort_T(:,j)));
            Max_T(j,1)=M;
            Max_T(j,2)=t(I);
    
            figure()
            plot(t,Effort_T(:,j))
            xlabel("Temps (s)")
            ylabel("Effort tangentiel (N)")
            title(['Effort tangentiel exerc� sur la section ',num2str(j)])
            saveas(gcf,fullfile([nom_dossier,'\Efforts\Effort tangentiel'],['Effort tangentiel section ',num2str(j)]));

        end
        
        %Courbe de l'effort tangentiel en fonction de l'abscisse x
        Eff_T_x=Effort_T(I_Pdyn_max,1:Nbr_section);
        figure()
        plot(xCDG0*0.001,Eff_T_x)
        xlabel("Abscisse (m)")
        ylabel("Effort Tangentiel (N)")
        title('Effort Tangentiel � pression dynamique max')
        saveas(gcf,fullfile([nom_dossier,'\Efforts\Effort tangentiel'],'Effort tangentiel fus�e'));

    %Moment de flexion
    mkdir([nom_dossier,'\Efforts'],'Moment de flexion');
        for j=1:1:Nbr_section
    
            Moment(1,j)=M_flexion(j,1);
            for i=0:1:pas_lim(1,1)-1
                Moment(i+1,j) = M_flexion(j+i*Nbr_section,1);
            end
            [M,I] = max(abs(Moment(:,j)));
            Max_M(j,1)=M;
            Max_M(j,2)=t(I);
    
            figure()
            plot(t,Moment(:,j))
            xlabel("Temps (s)")
            ylabel("Moment (N.m)")
            title(['Moment exerc� sur la section ',num2str(j)])
            saveas(gcf,fullfile([nom_dossier,'\Efforts\Moment de flexion'],['Moment section ',num2str(j)]));
    
        end
        
        %Courbe du moment en fonction de l'abscisse x
        M_x=Moment(I_Pdyn_max,1:Nbr_section);
        figure()
        plot(xCDG0*0.001,M_x)
        xlabel("Abscisse (m)")
        ylabel("Moment (N.m)")
        title('Moment exerc� � pression dynamique max')
        saveas(gcf,fullfile([nom_dossier,'\Efforts\Moment de flexion'],'Moment fus�e'));
        
save([nom_dossier,'\Efforts\Tableaux de valeurs'],'I_Pdyn_max','Max_N','Effort_N','Max_T','Effort_T','Max_M','Moment','Pdyn_max','t_Pdyn_max','Eff_N_x');

end
