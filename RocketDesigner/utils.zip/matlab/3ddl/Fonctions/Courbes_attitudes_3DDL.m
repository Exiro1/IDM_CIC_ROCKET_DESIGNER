function [] = Courbes_attitudes_3DDL(nom_dossier,Theta,t)

mkdir(nom_dossier,'Attitudes');

        %Tangage (th�ta)
        Theta = Theta*(180/pi);
        figure()
        plot(t,Theta)
        xlabel("Temps en seconde")
        ylabel("Tangage en �")
        title("Evolution du tangage en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Attitudes'],'Angle de tangage (theta)'));

end