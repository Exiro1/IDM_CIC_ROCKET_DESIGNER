function [] = Courbes_trajecto_3DDL(nom_dossier,x,z,accelerations,accelerations_ang,vitesses,vitesses_ang,Vitesse_vent_fusee,t)

mkdir(nom_dossier,'Trajectographie');

        %Courbe de l'altitude
        figure()
        plot(t,z)
        xlabel("Temps en secondes")
        ylabel("Altitude en m�tres")
        title("Evolution de l'altitude en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Altitude (z) vs Temps'));

        %Courbe de la port�e 
        figure()
        plot(x,z)
        xlabel("Port�e en m�tres")
        ylabel("Altitude en m�tres")
        title("Evolution de l'altitude en fonction de la port�e")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Altitude (z) vs Port�e (x)'));

        %Courbes des acc�l�rations
        figure()
        plot(t,accelerations)
        xlabel("Temps en secondes")
        ylabel("Acc�l�ration en m.s-2")
        title("Evolution des acc�l�rations en fonction du temps")
        legend('Ax','Az')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Acc�l�rations vs Temps'));
        
        figure()
        plot(t,accelerations_ang)
        xlabel("Temps en secondes")
        ylabel("Acc�l�ration angulaire en rad.s-2")
        title("Evolution de l'acc�l�ration angulaire en fonction du temps")
        legend('Ath�ta')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Acc�l�ration ang vs Temps'));

        figure()
        plot(z,accelerations)
        xlabel("Altitude en m�tres")
        ylabel("Acc�l�ration en m.s-2")
        title("Evolution des acc�l�rations en fonction de l'altitude")
        legend('Ax','Az')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Acc�l�rations vs Altitude'));

        %Courbes des vitesses
        
        figure()
        plot(t,Vitesse_vent_fusee)
        xlabel("Temps en secondes")
        ylabel("Vitesse en m.s-1")
        title("Evolution de la vitesse par rapport au vent en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Vitesse vent'));
        
        figure()
        plot(t,vitesses)
        xlabel("Temps en secondes")
        ylabel("Vitesse en m.s-1")
        title("Evolution des vitesses en fonction du temps")
        legend('Vx','Vz')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Vitesses vs Temps'));
        
        figure()
        plot(t,vitesses_ang)
        xlabel("Temps en secondes")
        ylabel("Vitesse angulaire en rad.s-1")
        title("Evolution de la vitesse angulaire en fonction du temps")
        legend('Vth�ta')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Vitesse ang vs Temps'));

        figure()
        plot(z,vitesses)
        xlabel("Altitude en m�tres")
        ylabel("Vitesse en m.s-1")
        title("Evolution des vitesses en fonction de l'altitude")
        legend('Vx','Vz')
        grid
        saveas(gcf,fullfile([nom_dossier,'\Trajectographie'],'Vitesses vs Altitude'));

end