function [] = Courbes_atmosphere_3DDL(nom_dossier,Temp_atmo,Pressu_atmo,Rho_atmo,Vitesse_son,Viscosite_atmo,t)

mkdir(nom_dossier,'Atmosphere');

        figure(1)
        plot(t,Temp_atmo)
        xlabel("Temps en secondes")
        ylabel("Temp�rature de l'atmosph�re en K")
        title("Evolution de la temp�rature de l'atmosph�re en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Atmosphere'],'Temp�rature'));

        figure(2)
        plot(t,Pressu_atmo)
        xlabel("Temps en secondes")
        ylabel("Pression de l'atmosph�re en Pa")
        title("Evolution de la pression de l'atmosph�re en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Atmosphere'],'Pression'));

        figure(3)
        plot(t,Rho_atmo)
        xlabel("Temps en secondes")
        ylabel("Masse volumique de l'atmosph�re en kg.m-3")
        title("Evolution de la masse volumique de l'atmosph�re en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Atmosphere'],'Masse volumique'));

        figure(4)
        plot(t,Vitesse_son)
        xlabel("Temps en secondes")
        ylabel("Vitesse du son en m.s-1")
        title("Evolution de la vitesse du son en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Atmosphere'],'Vitesse du son'));

        figure(5)
        plot(t,Viscosite_atmo)
        xlabel("Temps en secondes")
        ylabel("Viscosit� dynamique en Pa.s")
        title("Evolution de la viscosit� dynamique en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Atmosphere'],'Viscosit� dynamique'));

end