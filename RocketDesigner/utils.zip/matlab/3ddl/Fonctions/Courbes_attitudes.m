function [] = Courbes_attitudes(nom_dossier,Phi,Theta,Psi,t)

mkdir(nom_dossier,'Attitudes');

        %Roulis (Phi)
        Phi = Phi*(180/pi);
        figure()
        plot(t,Phi)
        xlabel("Temps en secondes")
        ylabel("Roulis en �")
        title("Evolution du roulis en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Attitudes'],'Angle de roulis (Phi)'));
        
        %Lacet (Psi)
        Psi = Psi*(180/pi);
        figure()
        plot(t,Psi)
        xlabel("Temps en secondes")
        ylabel("Lacet en �")
        title("Evolution du lacet en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Attitudes'],'Angle de lacet (Psi)'));

        %Tangage (th�ta)
        Theta = Theta*(180/pi);
        figure()
        plot(t,Theta)
        xlabel("Temps en secondes")
        ylabel("Tangage en �")
        title("Evolution du tangage en fonction du temps")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Attitudes'],'Angle de tangage (Theta)'));
        

end