%Ce fichier nous permet de r�unir toutes les donn�es g�n�rales de la fus�e
%pour ensuite les utiliser dans la fonction MAIN.
function [] = Structure_fusee()

%Dimensions de la fus�e
T_Donnees = readtable('Donn�es_Excel.xlsx','Sheet','Structure','Range','dryInfo');
T_Donnees=table2array(T_Donnees);

T_Donnees2 = readtable('Donn�es_Excel.xlsx','Sheet','Structure','Range','tankInfo');
T_Donnees2=table2array(T_Donnees2);



M_ergol=T_Donnees2(1,4)+T_Donnees2(2,4); %kg
M_tot=T_Donnees(1) + M_ergol; %kg
M_tot0 = T_Donnees(1) + M_ergol;
Ltot=T_Donnees(5);%mm

d=T_Donnees(6);%mm
Rlanceur=d/2; %Rayon du lanceur calcul� � partir du diam�tre
Sref=pi*((d*(1e-3))/2)^2; 

%masse ergol total au decollage


%Masses :  RocketDryMass   0  
%          tank1Mass       1 or 2  (1 = solid ; 2 = liquid)      reduc
%          tank2Mass       1 or 2  (1 = solid ; 2 = liquid)      oxy

M0=zeros(3,2);
M0(1,1) = T_Donnees(1);
M0(2,1) = T_Donnees2(1,4);
M0(2,2) = T_Donnees2(1,1);
M0(3,1) = T_Donnees2(2,4);
M0(3,2) = T_Donnees2(2,1);
M = M0;
TankInfo = zeros(2,4);
%                  hauteur          max ergol         posX             type
TankInfo(1,:) = [T_Donnees2(1,2) T_Donnees2(1,3) T_Donnees2(1,5) T_Donnees2(1,1)];
TankInfo(2,:) = [T_Donnees2(2,2) T_Donnees2(2,3) T_Donnees2(2,5) T_Donnees2(2,1)];

% Coordonn�es centrage
cdgInfo=zeros(3,1);
cdgInfo(1) = T_Donnees(2);

x1 = TankInfo(1,3) + TankInfo(1,1)/2;
if TankInfo(1,4) == 2
    x1 = TankInfo(1,3) + TankInfo(1,1)*(1-M0(2,1)/TankInfo(1,2));
end

x2 = TankInfo(2,3) + TankInfo(2,1)/2;
if TankInfo(2,4) == 2
    x2 = TankInfo(2,3) + TankInfo(2,1)*(1-M0(3,1)/TankInfo(2,2));
end

            %xcog
cdgInfo(2) = x1;
cdgInfo(3) = x2;

%Constantes
G = 6.6742*10^-11; %N*m�/kg�
Mterre = 5.972*10^24; %kg

save('Structure.mat')
movefile('Structure.mat','Donn�es');
end

