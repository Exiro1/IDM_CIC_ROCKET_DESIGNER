function [] = Courbes_Stabilite(nom_dossier,t,thrust,marge_stat,inc,cdg,cp,mach)

mkdir(nom_dossier,'Stabilite');

        %Thrust
        figure()
        plot(t,thrust)
        xlabel("temps en sec")
        ylabel("Poussée en N")
        title("Poussée de la fusée")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Stabilite'],'Poussee'));

        %Marge Statique
        figure()
        plot(t,marge_stat)
        xlabel("temps en sec")
        ylabel("Marge statique en mm")
        title("Marge Statique")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Stabilite'],'Marge_Statique'));
        
        %Incidence
        figure()
        plot(t,inc)
        xlabel("temps en sec")
        ylabel("Incidence en deg")
        title("Incidence")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Stabilite'],'Incidence'));
        
        %Centre de gravité
        figure()
        plot(t,cdg)
        xlabel("temps en sec")
        ylabel("Position CDG en mm")
        title("Centre de gravité")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Stabilite'],'CDG'));
        
         %Centre de pression
        figure()
        plot(t,cp)
        xlabel("temps en sec")
        ylabel("Position CP en mm")
        title("Centre de pression")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Stabilite'],'CP'));
        
        %Centre de pression
        figure()
        plot(t,mach)
        xlabel("temps en sec")
        ylabel("Mach")
        title("nombre de Mach")
        grid
        saveas(gcf,fullfile([nom_dossier,'\Stabilite'],'Mach'));
end