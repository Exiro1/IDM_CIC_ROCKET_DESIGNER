function [] = Aerodyn_fusee()

%Coefficients A�rodynamique
Cybeta=readtable('Donn�es_Excel.xlsx','Sheet','Aerodynamique','Range','Cybeta');
Cybeta=table2array(Cybeta);


save('Aerodyn.mat')
movefile('Aerodyn.mat','Donn�es');
end