close all


[freq1 , ampl1, t1,y1] = Frequencies(out.inc,out.time,2,15);
[freq2 , ampl2, t2,y2] = Frequencies(out.inc,out.time,35,70);

[pks,locs] = findpeaks(-out.inc);
len = size(pks)*[1;0];
firstOvershoot = pks(1);

[pks2,locs2] = findpeaks(y1);
secondOvershoot = pks2(1);
len2 = size(pks2)*[1;0];
%pks2 = pks2(2:len2)
%locs2 = locs2(2:len2)
locs2 = locs2
pks2 = transpose(pks2)

figure
hold on
plot(out.time,out.inc)
%plot(out.time(locs),-pks)
%plot(t1(locs2),pks2)

exval = fit(transpose(t1(locs2)),pks2,'exp1')
t = (0:0.1:20)
e = exval.a*exp(exval.b*t)

plot(exval)


