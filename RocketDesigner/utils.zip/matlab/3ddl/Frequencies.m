function [freq,ampl,t,y] = Frequencies(inc, time, start, endtime)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

Fs = 10;
T = 1/Fs;

timesample = linspace(start,endtime,(endtime-start)*Fs);
incevenlyspaced = interp1(time,inc,timesample);

L = size(timesample);
L = L(2);

Y = fft(incevenlyspaced);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);

f = Fs*(0:(L/2))/L;

%figure;
%plot(f,P1) ;
%title('Single-Sided Amplitude Spectrum of X(t)');
%xlabel('f (Hz)');
%ylabel('|P1(f)|');

[maxAmpl, freqMaxAmpl] = max(P1);
freq = f(freqMaxAmpl);
ampl = maxAmpl;
t = timesample;
y = incevenlyspaced;
end

