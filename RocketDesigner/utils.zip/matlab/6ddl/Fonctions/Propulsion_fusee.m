function [] = Propulsion_fusee()

%Propulsion
% Tableau de la loi de d�bit en fonction du temps
DebitInter=readtable('Donn�es_Excel.xlsx','Sheet','Propulsion','Range','Loi_Debit');
DebitInter=table2array(DebitInter);
% D�bit en fonction du temps
rMelange=readtable('Donn�es_Excel.xlsx','Sheet','Propulsion','Range','rMelange'); %RM=0 => propu solide
rMelange=table2array(rMelange);
Isp =readtable('Donn�es_Excel.xlsx','Sheet','Propulsion','Range','ISP');%s
Isp=table2array(Isp);
Se=readtable('Donn�es_Excel.xlsx','Sheet','Propulsion','Range','Se'); %Section de sortie de la tuy�re en m�
Se=table2array(Se);
x_CentrePoussee=readtable('Donn�es_Excel.xlsx','Sheet','Propulsion','Range','x_CentrePoussee');%mm
x_CentrePoussee=table2array(x_CentrePoussee);
G0 =readtable('Donn�es_Excel.xlsx','Sheet','Propulsion','Range','G0');
G0=table2array(G0);

save('Propu.mat')
movefile('Propu.mat','Donn�es');
end