clear all
close all
clc

addpath('6DDL','Donn�es','Fonctions');

T_simu=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','T_simu');
T_simu=table2array(T_simu); 

Structure_fusee();
Aerodyn_fusee();
Propulsion_fusee();
load('Donn�es\Structure.mat');
load('Donn�es\Aerodyn.mat');
load('aero.mat');
load('Donn�es\Propu.mat');

%Caract�ristiques Rampe
longueur_rampe=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','Longueur_rampe');
longueur_rampe=table2array(longueur_rampe); %m
Inclinaison_rampe=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','Pente_rampe');
Inclinaison_rampe=table2array(Inclinaison_rampe); %degr�s (rampe verticale si 90�)
q0i=cos((Inclinaison_rampe/2)*pi/180);
q1i=0;
q2i=sin((Inclinaison_rampe/2)*pi/180);
q3i=0;


%Conditions initiales
x0=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','x0');
x0=table2array(x0); %m (position initiale selon l'axe x)
y0=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','y0');
y0=table2array(y0); %m (position initiale selon l'axe y)
z0=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','z0');
z0=table2array(z0); %m (position initiale selon l'axe z)
Vx0=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','Vx0');
Vx0=table2array(Vx0); %m/s (vitesse initiale selon l'axe x)
Vy0=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','Vy0');
Vy0=table2array(Vy0); %m (vitesse initiale selon l'axe y)
Vz0=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','Vz0');
Vz0=table2array(Vz0); %m/s (vitesse initiale selon l'axe z)

T0=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','T0');
T0=table2array(T0); %K (Temp�rature au sol)
Nu0=readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','Nu0');
Nu0=table2array(Nu0); %Pa.s (Viscosit� dynamique de l'air au sol)

% Perturbations
Vitesse_vent = readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','V_vent');
Vitesse_vent=table2array(Vitesse_vent); %km/h
Orientation_vent =readtable('Donn�es_Excel.xlsx','Sheet','Conditions initiales','Range','Orientation_vent');
Orientation_vent=table2array(Orientation_vent); %degr�s
Vx_vent=(Vitesse_vent/3.6)*cos(Orientation_vent*pi/180);
Vy_vent=(Vitesse_vent/3.6)*sin(Orientation_vent*pi/180);
Vz_vent=0;

sim("Simulink_6DDL_V3.slx")

%Cr�ation du dossier de r�sultats
nom_dossier = char("savedData")
mkdir(nom_dossier);

%Trac� des courbes
Courbes_attitudes(nom_dossier,Phi,Theta,Psi,t);
Courbes_trajecto(nom_dossier,Portee,x,y,z,accelerations,accelerations_ang,vitesses,vitesses_ang,t);
Courbes_atmosphere(nom_dossier,Temp_atmo,Pressu_atmo,Rho_atmo,Vitesse_son,Viscosite_atmo,t);
Courbes_Stabilite(nom_dossier,t,thrust,marge_statique,inc,global_CDG,centrePression,mach);

save([nom_dossier,'\Donn�es de sortie'],'t');
