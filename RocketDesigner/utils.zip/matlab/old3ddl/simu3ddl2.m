function [incidence, mach, time, status] = simu3ddlm(IxCoef,IxOffset, mass, thrust, CAPowerOff2, CP2, CNalpha0To4DegperRad2, Sref, trueH, emass,cogCoef,cogOffset,As,Vx0)
%simu3ddl2 Summary of this function goes here
%   Detailed explanation goes here



runSimu = 1
h=5
a=1

q = emass / thrust(size(thrust)*[1 ; 0],1)

assignin('base','alphaMax', 30*3.141592/180);
assignin('base','incMax', 30*3.141592/180);
assignin('base','mass', mass);
assignin('base','emass', emass);
assignin('base','q', q);
assignin('base','thrustCurve', thrust);
assignin('base','CAPowerOff', transpose(CAPowerOff2));
assignin('base','CP', transpose(CP2));
assignin('base','CNalpha0To4DegperRad',transpose(CNalpha0To4DegperRad2));
assignin('base','Sref', Sref);
assignin('base','cogCoef', cogCoef);
assignin('base','cogOffset', cogOffset);
assignin('base','IxCoef', IxCoef);
assignin('base','IxOffset', IxOffset);
assignin('base','As', As);
assignin('base','VxSol', Vx0);
assignin('base','VySol', 0);

x=0
y=0

dt = 0.01

X = [0 h a h-a;a h-a a -h+a;a -h+a 2*a -h;2*a -h -2*a -h; -2*a -h -a -h+a;-a -h+a -a h-a;-a h-a 0 h]



%axis ([-10,10,-10,10]);

% X2 = M^-1(F-C*X1-K*X)

angle = 0;



%options = simset('SrcWorkspace','current');

%out = sim("simu3ddl.slx",[],options)
out = sim("simu3ddl.slx");

if runSimu == 1
figure

for i=1:7
    rotX = X(i,:);
    L(i) = line ([rotX(1),rotX(3)] , [rotX(2),rotX(4)]);
end

airspeed = line ([x,x-sin(out.inc(1))*2] , [y,y+cos(out.inc(1))*2]);

N = line ([x,x+out.N(1)] , [y-(out.Ms(1)/trueH)*2*h,y-(out.Ms(1)/trueH)*2*h]);

Nmax = max(max(out.N),-min(out.N))/8

timestepsize = size(out.time)

dt =  out.time(timestepsize(1))/timestepsize(1)

for k=1 : timestepsize(1)
    %plot([char])
    angle = -out.alpha(k);
    x = out.x(k);
    y = out.y(k);
    for i=1:7
    rotX = rotatePoint(X(i,:),angle) + [x y x y];
    set (L(i), 'XData',[rotX(1),rotX(3)], 'YData',[rotX(2),rotX(4)] );
    end
    minx = -(y+10)/2 + x;
    maxx = (y+10)/2 + x;
    
    %for q = 1:k
    %   rectangle('Position',[out.x(q) out.y(q) 1 1],'Curvature',[1 1]) 
    %end
    set (airspeed, 'XData',[x,(x+sin(-out.inc(k)+angle)*3)], 'YData',[y + h - (out.cog(k)/trueH)*2*h ,y-(out.cog(k)/trueH)*2*h-cos(-out.inc(k)+angle)*3] );
    
    N0 = rotatePoint([0 h-(out.CPval(k)/trueH)*2*h out.N(k)/Nmax  h-(out.CPval(k)/trueH)*2*h],angle);
    set (N, 'XData',[x+N0(1),x+N0(3)], 'YData',[y+N0(2),y+N0(4)] );
  
    axis ([x-10,x+10,y-10,y+10]);
    pause(dt);
    drawnow;
end

end

mach = out.mach;
incidence = out.inc;
time = out.time;

figure
plot(out.time, out.Ms)
title('Marge statique')
figure
plot(out.time, out.mach)
title('Mach')
figure
plot(out.time, out.inc)
title('Incidence')
figure
plot(out.time, out.y)
title('Altitude')
figure
plot(out.time, out.thrust)
title('Poussée')

if max(out.alphaTooHigh) == 1
    status = "Erreur : la fusée a dépassé l'assiette max au décollage"
elseif max(out.incTooHigh) == 1
    status = "Erreur : la fusée a dépassé l'incidence max en vol"
else
    status = "OK"
end

altitudeMax = max(out.y);
posXmax = max(out.x);
MargeStatiqueMin = min(out.Ms);
qinfMax = max(out.qinf);
machMax = max(out.mach)

status = status + ";"+altitudeMax+ ";"+MargeStatiqueMin+ ";"+qinfMax+ ";"+machMax

end

function X = rotatePoint(X0,angle)
    s = sin(angle);
    c = cos(angle);
    x1 = X0(1)*c-X0(2)*s;
    y1 = X0(1)*s+X0(2)*c;
    x2 = X0(3)*c-X0(4)*s;
    y2 = X0(3)*s+X0(4)*c;
    X = [x1,y1,x2,y2];
end


