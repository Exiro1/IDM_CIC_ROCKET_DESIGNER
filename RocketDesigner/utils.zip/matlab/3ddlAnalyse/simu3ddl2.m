clear all
close all
clc

addpath('Données','Fonctions');



Vx0 = table2array(readtable('Données_Excel.xlsx','Sheet','Conditions initiales','Range','V_vent'))/3.6;
Vy0 = 0;
runSimu = table2array(readtable('Données_Excel.xlsx','Sheet','Conditions initiales','Range','show_sim'));
showGraph = table2array(readtable('Données_Excel.xlsx','Sheet','Conditions initiales','Range','show_graph'));

alphaStart = 0*3.141592/180;

Structure_fusee();
Aerodyn_fusee();
Propulsion_fusee();
load('Données\Structure.mat');
load('aero.mat');
load('Données\Propu.mat');

alphaMax = 180*3.141592/180;
incMax = 30*3.141592/180;

h=5
a=1



x=0
y=0

dt = 0.01

X = [0 h a h-a;a h-a a -h+a;a -h+a 2*a -h;2*a -h -2*a -h; -2*a -h -a -h+a;-a -h+a -a h-a;-a h-a 0 h]



%axis ([-10,10,-10,10]);

% X2 = M^-1(F-C*X1-K*X)

angle = 0;

trueH = Ltot/1000;

%options = simset('SrcWorkspace','current');

%out = sim("simu3ddl.slx",[],options)


if verLessThan('matlab', '9.4')
    status = "VersionError"
    return
elseif verLessThan('matlab', '9.10')
    out = sim("sim3ddl2018.slx");
else
    out = sim("sim3ddl.slx");
end

if runSimu == 1

    if showGraph == 1
Msp = out.Ms(1);
machp = out.mach(1);
incp = out.inc(1);
altp = out.y(1);
thrustp = out.thrust(1);
massp = out.mass(1);
timep = out.time(1);

fms = figure
msplot = plot(timep, Msp,'XDataSource','timep','YDataSource','Msp','YLimInclude', 'off');
title('Marge statique');
xlim([min(out.time) max(out.time)]);
ylim([min(out.Ms) max(out.Ms)]);
axis manual
movegui(fms,'northeast');

fmach = figure
machplot = plot(timep, machp,'XDataSource','timep','YDataSource','machp');
title('Mach');
xlim([min(out.time) max(out.time)]);
ylim([min(out.mach) max(out.mach)]);
axis manual
movegui(fmach,'north');

finc = figure
incplot = plot(timep, incp,'XDataSource','timep','YDataSource','incp');
title('Incidence');
xlim([min(out.time) max(out.time)]);
ylim([min(out.inc) max(out.inc)]);
ylim([-0.01 0.01]);
axis manual
movegui(finc,'northwest');

falt = figure
altplot = plot(timep, altp,'XDataSource','timep','YDataSource','altp');
title('Altitude');
xlim([min(out.time) max(out.time)]);
ylim([min(out.y) max(out.y)]);
axis manual
movegui(falt,'southeast');

fthrust = figure
thrustplot = plot(timep, thrustp,'XDataSource','timep','YDataSource','thrustp');
title('Poussée');
xlim([min(out.time) max(out.time)]);
ylim([min(out.thrust) max(out.thrust)]);
axis manual
movegui(fthrust,'southwest');

fmass = figure
massplot = plot(timep, massp,'XDataSource','timep','YDataSource','massp');
title('Masse');
xlim([min(out.time) max(out.time)]);
ylim([min(out.mass) max(out.mass)]);
axis manual
movegui(fmass,'south');

    end
    
simuplot = figure(10)


for i=1:7
    rotX = X(i,:);
    L(i) = line ([rotX(1),rotX(3)] , [rotX(2),rotX(4)]);
end

airspeed = line ([x,x-sin(out.inc(1))*2] , [y,y+cos(out.inc(1))*2]);

N = line ([x,x+out.N(1)] , [y-(out.Ms(1)/trueH)*2*h,y-(out.Ms(1)/trueH)*2*h]);

Nmax = max(max(out.N),-min(out.N))/8

timestepsize = size(out.time)

dt =  out.time(timestepsize(1))/timestepsize(1)

out.time(timestepsize(1)+1) = out.time(timestepsize(1))+0.1

for k=1 : timestepsize(1)
    %plot([char])
    angle = out.alpha(k);
    x = out.x(k);
    y = out.y(k);
    for i=1:7
    rotX = rotatePoint(X(i,:),angle) + [x y x y];
    set (L(i), 'XData',[rotX(1),rotX(3)], 'YData',[rotX(2),rotX(4)] );
    end
    minx = -(y+10)/2 + x;
    maxx = (y+10)/2 + x;
    
    %for q = 1:k
    %   rectangle('Position',[out.x(q) out.y(q) 1 1],'Curvature',[1 1]) 
    %end
    C0 = rotatePoint([0 h-(out.cog(k)/trueH)*2*h sin(-out.inc(k))*3 -(out.cog(k)/trueH)*2*h-cos(-out.inc(k))*3],angle);
    set (airspeed, 'XData',[x+C0(1),x+C0(3)], 'YData',[y+C0(2),y+C0(4)] );
    
    N0 = rotatePoint([0 h-(out.CPval(k)/trueH)*2*h out.N(k)/Nmax  h-(out.CPval(k)/trueH)*2*h],angle);
    set (N, 'XData',[x+N0(1),x+N0(3)], 'YData',[y+N0(2),y+N0(4)] );
  
    
    xlim(simuplot.CurrentAxes,[x-10,x+10])
    ylim(simuplot.CurrentAxes,[y-10,y+10])
    %axis([x-10,x+10,y-10,y+10]);
    
    
    if showGraph == 1 && k < timestepsize(1)
        Msp = out.Ms(1:k+1);
        machp = out.mach(1:k+1);
        incp = out.inc(1:k+1);
        altp = out.y(1:k+1);
        thrustp = out.thrust(1:k+1);
        massp = out.mass(1:k+1);
        timep = out.time(1:k+1);
        refreshdata(msplot,'caller');
        refreshdata(machplot,'caller');
        refreshdata(incplot,'caller');
        refreshdata(altplot,'caller');
        refreshdata(thrustplot,'caller');
        refreshdata(massplot,'caller');
        
    end
    
    
    
    pause(out.time(k+1)-out.time(k));
    drawnow;
end

end

mach = out.mach;
incidence = out.inc;
time = out.time;



if max(out.alphaTooHigh) == 1
    status = "Erreur : la fusée a dépassé l'assiette max au décollage"
elseif max(out.incTooHigh) == 1
    status = "Erreur : la fusée a dépassé l'incidence max en vol"
else
    status = "OK"
end

altitudeMax = max(out.y);
posXmax = max(out.x);
MargeStatiqueMin = min(out.Ms);
qinfMax = max(out.qinf);
machMax = max(out.mach)

status = status + ";"+altitudeMax+ ";"+MargeStatiqueMin+ ";"+qinfMax+ ";"+machMax


function X = rotatePoint(X0,angle)
    s = sin(angle);
    c = cos(angle);
    x1 = X0(1)*c-X0(2)*s;
    y1 = X0(1)*s+X0(2)*c;
    x2 = X0(3)*c-X0(4)*s;
    y2 = X0(3)*s+X0(4)*c;
    X = [x1,y1,x2,y2];
end


